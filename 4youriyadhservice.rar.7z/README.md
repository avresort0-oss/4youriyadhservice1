# 4Your Riyadh Service

This is a Firebase-integrated landing page for services in Riyadh.

- Admin Panel to change Logo, WhatsApp links, and gallery.
- Subscriber-only WhatsApp link.
- Riyadh-only restriction.
- Mobile-first, responsive gallery with thumbnails.

## How to Use

1. Upload this folder to GitHub repository.
2. Set up GitHub Pages for this repo.
3. Replace Firebase config with your project details.
4. Open the live site: https://yourusername.github.io/4youriyadhservice/
